<!DOCTYPE html>
<html>
<head>
    <title>Detail User Page</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1>Detail User Page</h1>
        <!-- isi user detail (masih kosong) -->
        <a href="dashboard.php" class="btn btn-primary">Back to Dashboard</a>
        <br><br>
    </div>
</body>
</html>