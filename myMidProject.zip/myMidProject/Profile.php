<!DOCTYPE html>
<html>
<head>
    <title>Profile Page</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1>Profile Page</h1>
        <!-- isi profile page (masih kosong) -->
        <a href="login.php" class="btn btn-primary">Logout</a>
        <br><br>
    </div>
</body>
</html>