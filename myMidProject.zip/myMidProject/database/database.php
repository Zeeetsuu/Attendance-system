<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mymidproject";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi ke database gagal: " . $conn->connect_error);
}

date_default_timezone_set('Asia/Jakarta');
?>