CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    photo VARCHAR(255),
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    email VARCHAR(100),
    bio TEXT
);