<!DOCTYPE html>
<html>
<head>
    <title>Delete User Page</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1>Delete User Page</h1>
        <p>Are you sure you want to delete this user?</p>
        <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
        <a href="delete_user.php" class="btn btn-danger">Delete</a>
    </div>
</body>
</html>